package Cart;

import Productdetail.ProductDetail;
import Profil.Main_Profile;
import Profil.Profile;
import bestellsystem.GUI;
import bestellsystem.Head;
import bestellsystem.Homepage.Homepage;
import bestellsystem.OrderingSystem;
import bestellsystem.Product_Preview;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class Cart extends JPanel {

    public Cart(int userID) {
        setLayout(null);

        JPanel Head = new Head(400, 100, 5, "Your cart", null, null, userID, false, OrderingSystem.CL.Homepage, false);
        Head.setBounds(0, 0, GUI.SCREENWIDTH, 100);
        add(Head);

        JComponent Content = new JPanel(null);

        int pref_Height = 0;
        int padding = 25;
        int previews_per_row = 4;
        int w = (GUI.SCREENWIDTH - ((previews_per_row + 1) * padding)) / previews_per_row;
        int h = w + 50;

        ArrayList<Product_Preview> Previews = new ArrayList<>();
        ResultSet rs = OrderingSystem.CL.Database.processRequest("SELECT * FROM cart WHERE userID='" + userID + "' ORDER BY since DESC");
        double sum = 0;
        try {
            while (rs.next()) {
                int productID = rs.getInt("productID");
                int amount = rs.getInt("amount");
                Timestamp since = rs.getTimestamp("since");
                ResultSet rs2 = OrderingSystem.CL.Database.processRequest("SELECT * FROM product WHERE productID='" + productID + "'");
                ImageIcon img = null;
                String name = "";
                double price = 0;
                while (rs2.next()) {
                    img = Homepage.getImageFromBlob(rs2.getBlob("image"), w);
                    name = (rs2.getString("name"));
                    price = amount * rs2.getDouble("price");
                    sum += price;
                }
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yy");
                LocalDateTime ldt = since.toLocalDateTime();
                Previews.add(new Product_Preview(w, (h - w), img, name, amount, ("in cart since:" + ldt.format(formatter) + " | amount: " + amount + " | price: " + (ProductDetail.getPrice(price))), productID, userID, this));
                Previews.get(Previews.size() - 1).price = price;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Cart.class.getName()).log(Level.SEVERE, null, ex);
        }

        if (Previews.isEmpty()) {
            JPanel Explaination = new JPanel(new GridBagLayout());
            JLabel Maybe_Label = new JLabel("Your cart is empty. Add items by using the \"Add to cart\"-Button");
            Maybe_Label.setFont(Maybe_Label.getFont().deriveFont(36f));
            Explaination.add(Maybe_Label);
            Explaination.setBounds(0, 0, GUI.SCREENWIDTH, 50);
            Content.add(Explaination);
            Content.setBounds(0, 100, GUI.SCREENWIDTH, 50);
            add(Content);
            return;
        }

        int x = 0;
        int y = 0;
        for (int i = 0; i < Previews.size(); i++) {
            x = (i % previews_per_row) * (w) + (((i % previews_per_row) + 1) * padding);
            y = (i / previews_per_row) * (h) + (((i / previews_per_row) + 1) * padding);
            Previews.get(i).setBounds(x, y, w, h);
            Content.add(Previews.get(i));
            pref_Height = (y + h + padding);
        }

        String Ship_Adr = Main_Profile.getUserInformation("shippingAdress", 1, userID, "Checking shipping Adress!");
        String Bil_Adr = Main_Profile.getUserInformation("billingAdress", 1, userID, "Checking billing Adress!");

        JPanel Explaination = new JPanel(new GridBagLayout());
        JLabel Maybe_Label = new JLabel("Your total: " + ProductDetail.getPrice(sum) + " I " + ((Ship_Adr.equals("") || Bil_Adr.equals("")) ? "Please complete your information" : "Please confirm your information"));
        Maybe_Label.setFont(Maybe_Label.getFont().deriveFont(36f));
        Explaination.add(Maybe_Label);
        Explaination.setBounds(0, pref_Height, GUI.SCREENWIDTH, 50);
        Content.add(Explaination);
        pref_Height += 50;

        JTextField Shipping_Adress = new JTextField(Ship_Adr);
        InputPanel Ship_Panel = new InputPanel("Shipping Adress", "adress", Shipping_Adress, 525);
        Ship_Panel.setBounds(50, pref_Height, 525, 100);
        Content.add(Ship_Panel);

        JTextField Billing_Adress = new JTextField(Bil_Adr);
        InputPanel Bill_Panel = new InputPanel("Billing Adress", "adress", Billing_Adress, 525);
        Bill_Panel.setBounds(625, pref_Height, 525, 100);
        Content.add(Bill_Panel);
        pref_Height += 100;

        JPanel ButtonPanel = new JPanel(new GridBagLayout());

        JButton Button = new JButton("Complete order");
        Button.setPreferredSize(new Dimension(350, 50));
        Button.setFont(Button.getFont().deriveFont(34f));
        Button.setRolloverEnabled(false);
        Button.setFocusable(false);
        Button.setBorder(new LineBorder(Color.GRAY, 1));
        Button.setBackground(Color.ORANGE);
        ButtonPanel.add(Button);
        ButtonPanel.setBounds(0, (pref_Height + 25), GUI.SCREENWIDTH, 50);
        Content.add(ButtonPanel);
        pref_Height += 100;

        double final_sum = sum;
        Button.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if ((Shipping_Adress.getText().equals("") || Billing_Adress.getText().equals(""))) {
                    return;
                }

                //Check if there are still enough items in stock
                for (int i = 0; i < Previews.size(); i++) {
                    try {
                        ResultSet rs = OrderingSystem.CL.Database.processRequest("SELECT amount, name FROM product WHERE productID='" + Previews.get(i).productID + "'");
                        if (rs.next()) {
                            if (rs.getInt("amount") < Previews.get(i).amount) {
                                JOptionPane.showMessageDialog(null, "We`re sorry! Unfortunately, you can`t buy " + Previews.get(i).amount + " of " + rs.getString("name") + "!\nOnly " + rs.getInt("amount") + " are left.", "Error", JOptionPane.OK_OPTION);
                                return;
                            }
                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(Cart.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

                //Place the order
                String content = "";
                for (int i = 0; i < Previews.size(); i++) {
                    content += Previews.get(i).amount + "x" + Previews.get(i).productID + "x" + Previews.get(i).price;
                    if (i != Previews.size() - 1) {
                        content += "X";
                    } else {
                        content += "X" + final_sum;
                    }
                }
                OrderingSystem.CL.Database.executeStatement("INSERT INTO `order` (`orderID`, `userID`, `content`, `placed`, `shippingAdress`, `billingAdress`) VALUES (NULL, '" + userID + "', '" + content + "', NOW(), '" + Shipping_Adress.getText() + "', '" + Billing_Adress.getText() + "');");

                //Empty the cart
                OrderingSystem.CL.Database.executeStatement("DELETE FROM cart WHERE userID='" + userID + "'");

                //reduce the amounts
                for (int i = 0; i < Previews.size(); i++) {
                    try {
                        ResultSet rs = OrderingSystem.CL.Database.processRequest("SELECT amount FROM product WHERE productID='" + Previews.get(i).productID + "'");
                        if (rs.next()) {
                            OrderingSystem.CL.Database.executeStatement("UPDATE product SET amount = '" + (rs.getInt("amount") - Previews.get(i).amount) + "' WHERE productID = '" + Previews.get(i).productID + "'");
                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(Cart.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

                //Show Message and go back to Homepage
                JOptionPane.showMessageDialog(null, "Order placed!", "Success", JOptionPane.INFORMATION_MESSAGE);
                OrderingSystem.CL.Homepage.reloadCart(userID);
                OrderingSystem.CL.GUI.setBackground(OrderingSystem.CL.Homepage);
            }
        }
        );

        Content.setPreferredSize(
                new Dimension(GUI.SCREENWIDTH, pref_Height));
        if (pref_Height
                > 650) {
            JScrollPane scroller = new JScrollPane(Content);
            scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
            scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
            scroller.setBorder(null);
            scroller.setBounds(0, 100, GUI.SCREENWIDTH, 650);
            add(scroller);
        } else {
            Content.setBounds(0, 100, GUI.SCREENWIDTH, 650);
            add(Content);
        }

    }

}

class InputPanel extends JPanel {

    public InputPanel(String Text, String Icon, JComponent Input, int w) {
        setLayout(new GridLayout(2, 1));
        JPanel Panel_Label_Panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel Panel_Label = new JLabel(" " + Text);
        Panel_Label.setFont(Panel_Label.getFont().deriveFont(28f));
        Panel_Label.setIcon(new ImageIcon(new ImageIcon("src//bestellsystem//img//" + Icon + ".png").getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH)));
        Panel_Label_Panel.add(Panel_Label);
        add(Panel_Label_Panel);
        JPanel Panel_Input_Panel = new JPanel(null);
        Input.setBounds(5, 5, (w - 10), 40);
        Input.setFont(Input.getFont().deriveFont(22f));
        Panel_Input_Panel.add(Input);
        add(Panel_Input_Panel);
    }
}
