package OrderDetail;

import Productdetail.ProductDetail;
import static Productdetail.ProductDetail.getPrice;
import bestellsystem.GUI;
import bestellsystem.Head;
import bestellsystem.Homepage.Homepage;
import bestellsystem.OrderingSystem;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class OrderDetail extends JPanel {

    JPanel thisPanel;

    public OrderDetail(int orderID, int userID, JPanel Back) {
        setLayout(null);
        setBackground(OrderingSystem.Background);
        removeAll();

        thisPanel = this;

        int dig = 8;

        JPanel Head = new Head(400, 100, 5, "Orderdetail (orderID: " + "0".repeat(dig - (String.valueOf(orderID).length())) + orderID + ")", null, null, userID, false, Back, false);
        Head.setBounds(0, 0, bestellsystem.GUI.SCREENWIDTH, 100);
        add(Head);

        int pref_Height = 25;

        JPanel Content = new JPanel(null);

        ResultSet rs = OrderingSystem.CL.Database.processRequest("SELECT * FROM order WHERE orderID='" + orderID + "'");
        String shipping_adr = "";
        String billing_adr = "";
        Timestamp placed = null;
        String content = "";
        try {
            while (rs.next()) {
                shipping_adr = rs.getString("shippingAdress");
                billing_adr = rs.getString("billingAdress");
                placed = rs.getTimestamp("placed");
                content = rs.getString("content");
            }
        } catch (SQLException ex) {
            Logger.getLogger(OrderDetail.class.getName()).log(Level.SEVERE, null, ex);
        }

        JLabel Shipping_Adress = new JLabel(shipping_adr);
        InputPanel Ship_Panel = new InputPanel("Shipping Adress", "adress", Shipping_Adress, 400);
        Ship_Panel.setBounds(25, pref_Height, 400, 100);
        Content.add(Ship_Panel);

        JLabel Billing_Adress = new JLabel(billing_adr);
        InputPanel Bill_Panel = new InputPanel("Billing Adress", "adress", Billing_Adress, 400);
        Bill_Panel.setBounds(450, pref_Height, 400, 100);
        Content.add(Bill_Panel);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");
        LocalDateTime ldt = placed.toLocalDateTime();
        JLabel Placed_Label = new JLabel(ldt.format(formatter));
        InputPanel Placed_Panel = new InputPanel("Placed on", "clock", Placed_Label, 200);
        Placed_Panel.setBounds(875, pref_Height, 200, 100);
        Content.add(Placed_Panel);

        int amountOfItems = content.split("X").length;
        double Total = Double.parseDouble(content.split("X")[amountOfItems - 1]);
        JLabel Total_Label = new JLabel("" + getPrice(Total));
        InputPanel Total_Panel = new InputPanel("Total", "money", Total_Label, 125);
        Total_Panel.setBounds(1100, pref_Height, 125, 100);
        Content.add(Total_Panel);

        pref_Height += 100;

        JPanel Border = new JPanel();
        Border.setBounds(25, (pref_Height + 24), 1200, 1);
        Border.setBackground(Color.GRAY);
        Content.add(Border);

        pref_Height += 25;

        int items_per_row = 2;
        int padding = 25;
        int w = (GUI.SCREENWIDTH - (items_per_row + 1) * padding) / items_per_row;
        int h = 250;
        int x = 0;
        int y = 0;
        for (int i = 0; i < content.split("X").length - 1; i++) {
            int amount = Integer.parseInt(content.split("X")[i].split("x")[0]);
            int productID = Integer.parseInt(content.split("X")[i].split("x")[1]);
            double price = Double.parseDouble(content.split("X")[i].split("x")[2]);
            ImageIcon img = null;
            String name = "";

            rs = OrderingSystem.CL.Database.processRequest("SELECT name, image FROM product WHERE productID='" + productID + "'");
            try {
                while (rs.next()) {
                    img = Homepage.getImageFromBlob(rs.getBlob("image"), h);
                    name = rs.getString("name");
                }
            } catch (SQLException ex) {
                Logger.getLogger(OrderDetail.class.getName()).log(Level.SEVERE, null, ex);
            }

            JPanel Product = new JPanel(null);
            Product.setBackground(new Color(245, 245, 245));

            JLabel Image_Label = new JLabel(img);
            Image_Label.addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    ProductDetail PD = new ProductDetail(productID, userID, thisPanel, 0);
                    OrderingSystem.CL.GUI.setBackground(PD);
                }
            });
            Image_Label.setBounds(0, 0, h, h);
            Product.add(Image_Label);

            JLabel Name_ID_Label = new JLabel(name + " (productID: " + productID + ")");
            Name_ID_Label.setFont(Name_ID_Label.getFont().deriveFont(20f));
            Name_ID_Label.setBounds((h + 10), 0, (w - (h + 10)), 25);
            Product.add(Name_ID_Label);

            JLabel amount_label = new JLabel("amount: " + amount);
            amount_label.setFont(amount_label.getFont().deriveFont(16f));
            amount_label.setBounds((h + 10), 25, (w - (h + 10)), 25);
            Product.add(amount_label);

            JLabel price_label = new JLabel("price: " + getPrice(price / amount));
            price_label.setFont(price_label.getFont().deriveFont(16f));
            price_label.setBounds((h + 10), 50, (w - (h + 10)), 25);
            Product.add(price_label);

            JLabel total_label = new JLabel("Total: " + getPrice(price));
            total_label.setFont(total_label.getFont().deriveFont(16f));
            total_label.setBounds((h + 10), 75, (w - (h + 10)), 25);
            Product.add(total_label);

            int stars = -1;
            String review = "You did not leave a review yet. Click to create one.";
            rs = OrderingSystem.CL.Database.processRequest("SELECT * FROM review WHERE userID='" + userID + "' AND productID='" + productID + "'");
            try {
                if (rs.next()) {
                    stars = rs.getInt("stars");
                    review = rs.getString("comment");
                }
            } catch (SQLException ex) {
                Logger.getLogger(OrderDetail.class.getName()).log(Level.SEVERE, null, ex);
            }

            JLabel review_heading = new JLabel("Your review:");
            review_heading.setFont(review_heading.getFont().deriveFont(16f));
            review_heading.setBounds((h + 10), 100, (w - (h + 10)), 25);
            Product.add(review_heading);

            JLabel star_label = new JLabel(new ImageIcon(new ImageIcon("src//bestellsystem//img//rating//rating_" + stars + ".png").getImage().getScaledInstance(100, 20, Image.SCALE_SMOOTH)));
            star_label.setFont(star_label.getFont().deriveFont(16f));
            star_label.setBounds((h + 120), 102, (100), 20);
            Product.add(star_label);

            JTextArea Review = new JTextArea(review);

            JLabel Delete_Label = new JLabel(new ImageIcon(new ImageIcon("src//bestellsystem//img//delete.png").getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH)));
            Delete_Label.setBounds((w - 25), 100, 25, 25);
            Product.add(Delete_Label);
            if (!hasReview(userID, productID)) {
                Delete_Label.setVisible(false);
            }

            Delete_Label.addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    if (!hasReview(userID, productID)) {
                        return;
                    }
                    int input = -1;
                    String comment = "You did not leave a review yet. Click to create one.";
                    star_label.setIcon(new ImageIcon(new ImageIcon("src//bestellsystem//img//rating//rating_" + input + ".png").getImage().getScaledInstance(100, 20, Image.SCALE_SMOOTH)));
                    Review.setText(comment);
                    Delete_Label.setVisible(false);

                    OrderingSystem.CL.Database.executeStatement("DELETE FROM review WHERE userID='" + userID + "' AND productID='" + productID + "'");
                }
            });

            Review.addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    if (hasReview(userID, productID)) {
                        return;
                    }
                    boolean error = false;
                    try {
                        int input = Integer.parseInt((String) JOptionPane.showInputDialog(null, "Select a rating 1 (bad) - 5 (good):", "How do you like this product?", JOptionPane.QUESTION_MESSAGE, null, new String[]{"1", "2", "3", "4", "5"}, "1"));
                        String comment = (String) JOptionPane.showInputDialog(null, "Please leave a comment: ", "How do you like this product?", JOptionPane.QUESTION_MESSAGE);
                        if (comment == null) {
                            error = true;
                        } else {
                            Review.setText(comment);
                            star_label.setIcon(new ImageIcon(new ImageIcon("src//bestellsystem//img//rating//rating_" + input + ".png").getImage().getScaledInstance(100, 20, Image.SCALE_SMOOTH)));
                            Delete_Label.setVisible(true);
                            OrderingSystem.CL.Database.executeStatement("INSERT INTO `review` (`reviewID`, `userID`, `productID`, `stars`, `comment`, `posted`) VALUES (NULL, '" + userID + "', '" + productID + "', '" + input + "', '" + comment + "', NOW());");
                        }
                    } catch (Exception ex) {
                        error = true;
                    }

                    if (error) {
                        JOptionPane.showMessageDialog(null, "Please select a rating and leave a comment!", "Error", JOptionPane.OK_OPTION);

                    }

                }
            });
            Review.setBorder(null);
            Review.setBackground(Product.getBackground());
            Review.setEditable(false);
            Review.setWrapStyleWord(true);
            Review.setLineWrap(true);
            Review.setBounds((h + 15), 130, (w - (h + 20)), (h - 135));
            Product.add(Review);

            x = (i % items_per_row) * (w) + (((i % items_per_row) + 1) * padding);
            y = pref_Height + (i / items_per_row) * (h) + (((i / items_per_row) + 1) * padding);
            Product.setBounds(x, y, w, h);
            Content.add(Product);
        }

        pref_Height += (amountOfItems / 2) * 275;
        pref_Height += padding;

        Content.setPreferredSize(new Dimension(GUI.SCREENWIDTH, pref_Height));
        if (pref_Height > 650) {
            JScrollPane scroller = new JScrollPane(Content);
            scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
            scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
            scroller.setBorder(null);
            scroller.setBounds(0, 100, GUI.SCREENWIDTH, 650);
            add(scroller);
        } else {
            Content.setBounds(0, 100, GUI.SCREENWIDTH, 650);
            add(Content);
        }
    }

    private boolean hasReview(int userID, int productID) {
        ResultSet rs = OrderingSystem.CL.Database.processRequest("SELECT * FROM review WHERE userID='" + userID + "' AND productID='" + productID + "'");
        try {
            if (rs.next()) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(OrderDetail.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}

class InputPanel extends JPanel {

    public InputPanel(String Text, String Icon, JComponent Input, int w) {
        setLayout(new GridLayout(2, 1));
        JPanel Panel_Label_Panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel Panel_Label = new JLabel(" " + Text);
        Panel_Label.setFont(Panel_Label.getFont().deriveFont(28f));
        Panel_Label.setIcon(new ImageIcon(new ImageIcon("src//bestellsystem//img//" + Icon + ".png").getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH)));
        Panel_Label_Panel.add(Panel_Label);
        add(Panel_Label_Panel);
        JPanel Panel_Input_Panel = new JPanel(null);
        Input.setBounds(5, 5, (w - 10), 40);
        Input.setFont(Input.getFont().deriveFont(22f));
        Panel_Input_Panel.add(Input);
        add(Panel_Input_Panel);
    }
}
