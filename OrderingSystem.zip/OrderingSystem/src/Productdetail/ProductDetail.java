package Productdetail;

import bestellsystem.Head;
import bestellsystem.Homepage.Homepage;
import bestellsystem.OrderingSystem;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class ProductDetail extends JPanel {

    private boolean isfav;
    ProductDetail thisPanel;

    public ProductDetail(int productID, int userID, JPanel Back, int Order_By_Option) {
        setLayout(null);
        thisPanel = this;
        removeAll();

        JPanel Head = new Head(400, 100, 5, "Productdetail", null, null, userID, false, Back, false);
        Head.setBounds(0, 0, bestellsystem.GUI.SCREENWIDTH, 100);
        add(Head);

        ResultSet rs = OrderingSystem.CL.Database.processRequest("SELECT * FROM product WHERE productID='" + productID + "'");

        ImageIcon img = null;
        int categoryID = 0;
        String category_name = "";
        String name = "";
        String descr = "";
        double price = 0;
        double maxprice = 0;
        int amount = 0;
        int minamount = 0;
        int maxamount = 0;
        isfav = false;
        try {
            if (rs.next()) {
                img = Homepage.getImageFromBlob(rs.getBlob("image"), 550);
                categoryID = rs.getInt("categoryID");
                name = rs.getString("name");
                descr = rs.getString("description");
                price = rs.getDouble("price");
                maxprice = rs.getDouble("maxprice");
                amount = rs.getInt("amount");
                minamount = rs.getInt("minamount");
                maxamount = rs.getInt("maxamount");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProductDetail.class.getName()).log(Level.SEVERE, null, ex);
        }

        rs = OrderingSystem.CL.Database.processRequest("SELECT * FROM isfavorite WHERE productID='" + productID + "' AND userID='" + userID + "'");
        try {
            if (rs.next()) {
                isfav = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProductDetail.class.getName()).log(Level.SEVERE, null, ex);
        }

        rs = OrderingSystem.CL.Database.processRequest("SELECT name FROM category WHERE categoryID='" + categoryID + "'");
        try {
            if (rs.next()) {
                category_name = rs.getString("name");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProductDetail.class.getName()).log(Level.SEVERE, null, ex);
        }

        JLabel Icon = new JLabel(img);
        Icon.setBounds(50, 150, 550, 550);
        add(Icon);

        JPanel Content = new JPanel(null);

        JLabel Name_Label = new JLabel(name);
        Name_Label.setFont(Name_Label.getFont().deriveFont(36f));
        Name_Label.setBounds(0, 0, 200, 50);
        Content.add(Name_Label);

        rs = OrderingSystem.CL.Database.processRequest("SELECT * FROM review WHERE productID='" + productID + "'");
        ArrayList<review> all_reviews_for_product = new ArrayList<>();
        int reviewsum = 0;
        try {
            while (rs.next()) {
                reviewsum += rs.getInt("stars");
                all_reviews_for_product.add(new review(rs.getInt("reviewID"), rs.getInt("userID"), productID, rs.getInt("stars"), rs.getString("comment"), rs.getTimestamp("posted"), userID));
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProductDetail.class.getName()).log(Level.SEVERE, null, ex);
        }

        String avg_review = String.format("%.1f", ((double) reviewsum / all_reviews_for_product.size()));
        JLabel stars_Label = new JLabel();
        String stars = rundeAufHalbe(avg_review).replace(",", ".");
        stars_Label.setIcon(new ImageIcon(new ImageIcon("src//bestellsystem//img//rating//rating_" + stars + ".png").getImage().getScaledInstance(150, 30, Image.SCALE_SMOOTH)));
        stars_Label.setBounds(275, 10, 150, 30);
        Content.add(stars_Label);

        JLabel avg_review_label = new JLabel(avg_review);
        avg_review_label.setFont(avg_review_label.getFont().deriveFont(36f));
        avg_review_label.setBounds(430, 0, 50, 50);
        Content.add(avg_review_label);

        JLabel Fav_Label = new JLabel();
        Fav_Label.setIcon(new ImageIcon(new ImageIcon("src//bestellsystem//img//heart" + (isfav ? "_red" : "") + ".png").getImage().getScaledInstance(45, 45, Image.SCALE_SMOOTH)));
        Fav_Label.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if (isfav) {
                    OrderingSystem.CL.Database.executeStatement("DELETE FROM isfavorite WHERE productID='" + productID + "' AND userID='" + userID + "'");
                } else {
                    OrderingSystem.CL.Database.executeStatement("INSERT INTO isfavorite (`productID`, `userID`, `since`) VALUES ('" + productID + "', '" + userID + "', NOW())");
                }

                isfav = !isfav;
                Fav_Label.setIcon(new ImageIcon(new ImageIcon("src//bestellsystem//img//heart" + (isfav ? "_red" : "") + ".png").getImage().getScaledInstance(45, 45, Image.SCALE_SMOOTH)));
            }
        });
        Fav_Label.setBounds(500, 0, 50, 50);
        Content.add(Fav_Label);

        JLabel Category_PID = new JLabel("Category: " + category_name + " (" + categoryID + ") | product-ID: " + productID);
        Category_PID.setFont(Category_PID.getFont().deriveFont(12f));
        Category_PID.setBounds(0, 50, 550, 25);
        Content.add(Category_PID);

        JTextArea Desc = new JTextArea(descr);
        Desc.setFont(Desc.getFont().deriveFont(16f));
        Desc.setBackground(getBackground());
        Desc.setWrapStyleWord(true);
        Desc.setLineWrap(true);
        Desc.setBounds(0, 90, 550, 150);
        Desc.setEditable(false);
        Content.add(Desc);

        JLabel price_Label = new JLabel("current price: " + getPrice(price));
        price_Label.setFont(price_Label.getFont().deriveFont(20f));
        price_Label.setBounds(0, 255, 250, 45);
        Content.add(price_Label);

        if (maxprice > price) {
            JLabel new_price_Label = new JLabel("-" + Math.round((1 - ((double) price / maxprice)) * 100) + "% (original price: " + getPrice(maxprice) + ")");
            new_price_Label.setFont(new_price_Label.getFont().deriveFont(20f));
            new_price_Label.setForeground(Color.red);
            new_price_Label.setBounds(250, 255, 300, 45);
            Content.add(new_price_Label);
        }

        JLabel amount_Label = new JLabel("in stock: " + amount);
        amount_Label.setFont(amount_Label.getFont().deriveFont(16f));
        amount_Label.setBounds(0, 300, 200, 35);
        Content.add(amount_Label);

        JLabel req_amount_Label = new JLabel("prescribed order size: min. " + minamount + (maxamount != -1 ? (" / max. " + maxamount) : ""));
        req_amount_Label.setFont(req_amount_Label.getFont().deriveFont(16f));
        req_amount_Label.setBounds(250, 300, 300, 35);
        Content.add(req_amount_Label);

        int amount_in_cart = -1;
        rs = OrderingSystem.CL.Database.processRequest("SELECT amount FROM cart WHERE userID='" + userID + "' AND productID='" + productID + "'");
        try {
            if (rs.next()) {
                amount_in_cart = rs.getInt("amount");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProductDetail.class.getName()).log(Level.SEVERE, null, ex);
        }

        JLabel amountChooser_Label = new JLabel(amount_in_cart == -1 ? "amount: " : "in cart:");
        amountChooser_Label.setFont(req_amount_Label.getFont().deriveFont(16f));
        amountChooser_Label.setBounds(0, 345, 75, 35);
        Content.add(amountChooser_Label);

        JTextField AmountChooser = new JTextField(amount_in_cart == -1 ? "" + minamount : "" + amount_in_cart);
        AmountChooser.setEditable((amount_in_cart == -1));
        AmountChooser.setFont(req_amount_Label.getFont().deriveFont(16f));
        AmountChooser.setBounds(80, 350, 50, 25);
        Content.add(AmountChooser);

        final int minamount_final = minamount;
        final int maxamount_final = maxamount == -1 ? Integer.MAX_VALUE : maxamount;
        final int amount_final = amount;

        JButton Cart_Button = new JButton(amount_in_cart == -1 ? "Add to cart" : "Delete from cart");
        Cart_Button.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if (isInCart(userID, productID)) {
                    OrderingSystem.CL.Database.executeStatement("DELETE FROM cart WHERE userID='" + userID + "' AND productID='" + productID + "'");
                    Cart_Button.setText("Add to cart");
                    amountChooser_Label.setText("amount: ");
                    AmountChooser.setEditable(true);
                    AmountChooser.setText("" + minamount_final);
                    return;
                }

                try {
                    int Menge = Integer.parseInt(AmountChooser.getText());
                    if (Menge < minamount_final || Menge > maxamount_final) {
                        JOptionPane.showMessageDialog(null, "Choose an approved amount!", "Error", JOptionPane.OK_OPTION);
                        return;
                    }

                    if (Menge > amount_final) {
                        JOptionPane.showMessageDialog(null, "Not enough items in stock!", "Error", JOptionPane.OK_OPTION);
                        return;
                    }

                    OrderingSystem.CL.Database.executeStatement("INSERT INTO cart (`userID`, `productID`, `amount`, `since`) VALUES ('" + userID + "', '" + productID + "', '" + Menge + "', NOW())");
                    amountChooser_Label.setText("in cart: ");
                    AmountChooser.setEditable(false);
                    AmountChooser.setText("" + Menge);
                    Cart_Button.setText("Delete from cart");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Put in a number!", "Error", JOptionPane.OK_OPTION);
                }
            }
        });
        Cart_Button.setPreferredSize(new Dimension(350, 25));
        Cart_Button.setFont(Cart_Button.getFont().deriveFont(20f));
        Cart_Button.setRolloverEnabled(false);
        Cart_Button.setFocusable(false);
        Cart_Button.setBorder(new LineBorder(Color.GRAY, 1));
        Cart_Button.setBackground(Color.ORANGE);
        Cart_Button.setBounds(250, 345, 300, 35);
        Content.add(Cart_Button);

        JPanel Also_Like = new Suggested_Products(productID, userID, thisPanel);
        Also_Like.setBounds(0, 390, 225, 160);
        Content.add(Also_Like);

        JPanel Reviews = new Reviews(all_reviews_for_product, userID, Order_By_Option);
        Reviews.setBounds(250, 390, 300, 160);
        Content.add(Reviews);

        Content.setBounds(650, 150, 550, 550);
        add(Content);
    }

    private boolean isInCart(int userID, int productID) {
        ResultSet rs = OrderingSystem.CL.Database.processRequest("SELECT * FROM cart WHERE userID='" + userID + "' AND productID='" + productID + "'");
        try {
            if (rs.next()) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProductDetail.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    static String rundeAufHalbe(String input) {
        double wert = Double.parseDouble(input.replace(",", "."));
        double gerundet = Math.round(wert * 2) / 2.0;

        if (gerundet == Math.floor(gerundet)) {
            return String.valueOf((int) gerundet); // z.B. "3"
        } else {
            return String.format("%.1f", gerundet); // z.B. "2.5"
        }
    }

    public static String getPrice(double price) {
        int i = String.valueOf(price).indexOf(".");
        if (price % 1 == 0) {
            if (price > 1000) {
                return String.valueOf(price).substring(0, (i)) + "€";
            } else {
                return String.valueOf(price).substring(0, (i)) + ".00€";
            }
        } else {
            return String.valueOf(price).substring(0, (i + 2)) + "0€";
        }
    }
}
