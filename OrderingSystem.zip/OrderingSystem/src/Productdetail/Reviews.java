package Productdetail;

import Profil.Main_Profile;
import bestellsystem.OrderingSystem;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.SpinnerListModel;
import javax.swing.SwingUtilities;

public class Reviews extends JPanel {

    String[] Order_By_Options = {"Newest       ", "Oldest      ", "Highest      ", "Lowest       ", "Most useful "};
    JPanel Review_Content;
    JScrollPane scroller;

    public Reviews(ArrayList<review> allreviews, int userID, int Order_By_Option) {
        setLayout(null);

        JLabel Review_Heading = new JLabel("Reviews");
        Review_Heading.setFont(Review_Heading.getFont().deriveFont(16f));
        Review_Heading.setBounds(0, 0, 100, 25);
        add(Review_Heading);

        ArrayList<review> cloned = (ArrayList<review>) allreviews.clone();
        Review_Content = Review_Content(cloned, userID, Order_By_Option);
        scroller = new JScrollPane(Review_Content);
        scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        scroller.setBounds(0, 25, 300, 135);
        scroller.setBorder(null);
        add(scroller);

        SwingUtilities.invokeLater(() -> {
            scroller.getVerticalScrollBar().setValue(0);
        });

        JComboBox chooser = new JComboBox(Order_By_Options);
        chooser.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                remove(scroller);

                ArrayList<review> cloned = (ArrayList<review>) allreviews.clone();

                int i = 0;
                for (int j = 0; j < Order_By_Options.length; j++) {
                    if (Order_By_Options[j].equals(chooser.getSelectedItem())) {
                        i = j;
                        break;
                    }
                }

                Review_Content = Review_Content(cloned, userID, i);
                scroller = new JScrollPane(Review_Content);
                scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
                scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
                scroller.setBounds(0, 25, 300, 135);
                scroller.setBorder(null);
                add(scroller);

                SwingUtilities.invokeLater(() -> {
                    scroller.getVerticalScrollBar().setValue(0);
                });
            }
        });
        chooser.setBounds(200, 0, 100, 25);
        add(chooser);
    }

    private JPanel Review_Content(ArrayList<review> reviews, int userID, int Order_By_Option) {
        JPanel Review_Content = new JPanel(null);

        review user_review = null;
        for (review r : reviews) {
            if (userID == r.verfasserID) {
                user_review = r;
                reviews.remove(r);
                break;
            }
        }

        switch (Order_By_Option) {
            case 0:
                reviews.sort(Comparator.comparing(r -> r.posted));
                Collections.reverse(reviews);
                break;
            case 1:
                reviews.sort(Comparator.comparing(r -> r.posted));
                break;
            case 2:
                reviews.sort(Comparator.comparing(r -> r.stars));
                Collections.reverse(reviews);
                break;
            case 3:
                reviews.sort(Comparator.comparing(r -> r.stars));
                break;
            case 4:
                reviews.sort(Comparator.comparing(r -> r.amountOfLikes));
                Collections.reverse(reviews);
                break;
        }

        ArrayList<review> Sorted = new ArrayList<>();
        if (user_review != null) {
            Sorted.add(user_review);
        }
        Sorted.addAll(reviews);
        reviews = Sorted;

        int sumheight = 0;
        int padding = 5;
        for (review r : reviews) {
            JPanel cont = r.createPanel();
            int height = cont.getPreferredSize().height;
            cont.setBounds(0, sumheight, 300, height);
            Review_Content.add(cont);
            sumheight += height;
            sumheight += padding;
        }

        Review_Content.setPreferredSize(new Dimension(300, sumheight));
        return Review_Content;
    }
}

class review {

    int reviewID;
    int verfasserID;
    int productID;
    int stars;
    String comment;
    Timestamp posted;
    int userID;

    boolean isLiked = false;
    int amountOfLikes = 0;

    public review(int reviewID, int verfasserID, int productID, int stars, String comment, Timestamp posted, int userID) {
        this.reviewID = reviewID;
        this.verfasserID = verfasserID;
        this.productID = productID;
        this.stars = stars;
        this.comment = comment;
        this.posted = posted;
        this.userID = userID;
        loadLikes();
    }

    void loadLikes() {
        //direkt count abfragen: ResultSet rs = OrderingSystem.CL.Database.processRequest("SELECT COUNT(DISTINCT userID) AS count FROM `likedreview` WHERE reviewID='"+reviewID+"'");
        ResultSet rs = OrderingSystem.CL.Database.processRequest("SELECT * FROM `likedreview` WHERE reviewID='" + reviewID + "'");
        try {
            while (rs.next()) {
                amountOfLikes++;
                if (rs.getInt("userID") == userID) {
                    isLiked = true;
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(review.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    JPanel createPanel() {
        JPanel reviewPanel = new JPanel(null);

        JLabel stars = new JLabel(new ImageIcon(new ImageIcon("src//bestellsystem//img//rating//rating_" + this.stars + ".png").getImage().getScaledInstance(125, 25, Image.SCALE_SMOOTH)));
        stars.setBounds(0, 5, 125, 25);
        reviewPanel.add(stars);

        String Name = userID == verfasserID ? "You" : Main_Profile.getUserInformation("name", 1, verfasserID, "Checking name");
        JLabel name = new JLabel(Name);
        name.setFont(name.getFont().deriveFont(16f));
        name.setBounds(135, 0, 50, 30);
        reviewPanel.add(name);

        JLabel amount_likes = new JLabel(amountOfLikes + " likes");
        amount_likes.setFont(amount_likes.getFont().deriveFont(10f));
        amount_likes.setBounds(215, 15, 55, 15);
        reviewPanel.add(amount_likes);

        JLabel Thumb_Icon = new JLabel(new ImageIcon(new ImageIcon("src//bestellsystem//img//thumb_" + (isLiked ? "filled" : "normal") + ".png").getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH)));
        Thumb_Icon.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                amountOfLikes += (isLiked ? -1 : 1);
                amount_likes.setText(amountOfLikes + " likes");
                Thumb_Icon.setIcon(new ImageIcon(new ImageIcon("src//bestellsystem//img//thumb_" + (isLiked ? "normal" : "filled") + ".png").getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH)));
                OrderingSystem.CL.Database.executeStatement(isLiked ? "DELETE FROM `likedreview` WHERE reviewID='" + reviewID + "' AND userID='" + userID + "'" : "INSERT INTO `likedreview` (reviewID, userID) VALUES ('" + reviewID + "', '" + userID + "')");
                isLiked = !isLiked;
            }
        });
        Thumb_Icon.setBounds(270, 0, 30, 30);
        reviewPanel.add(Thumb_Icon);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        LocalDateTime ldt = posted.toLocalDateTime();
        JLabel posted_Label = new JLabel(ldt.format(formatter));
        posted_Label.setFont(posted_Label.getFont().deriveFont(10f));
        posted_Label.setBounds(215, 0, 55, 15);
        reviewPanel.add(posted_Label);

        JTextArea content = new JTextArea(comment);

        content.setBackground(reviewPanel.getBackground());
        content.setEditable(false);
        content.setWrapStyleWord(true);
        content.setLineWrap(true);

        int height = berechneTextHoehe(comment, 300, content.getFont());
        content.setBounds(0, 30, 300, height);
        reviewPanel.add(content);

        reviewPanel.setPreferredSize(new Dimension(300, (height + 30)));
        return reviewPanel;
    }

    int berechneTextHoehe(String text, int breite, Font font) {
        JTextArea dummy = new JTextArea(text);
        dummy.setFont(font);
        dummy.setLineWrap(true);
        dummy.setWrapStyleWord(true);
        dummy.setSize(breite, Integer.MAX_VALUE); // Breite fixieren, Höhe beliebig groß

        return dummy.getPreferredSize().height;
    }

    public String toString() {
        return "ID: " + reviewID;
        //return "Review ID: " + reviewID + " by: " + verfasserID + " on product: " + productID + " / rating: " + stars + ": " + comment + "(" + posted + ")";
    }

}
