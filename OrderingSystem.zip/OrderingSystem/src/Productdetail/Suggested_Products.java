package Productdetail;

import bestellsystem.Homepage.Homepage;
import bestellsystem.OrderingSystem;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class Suggested_Products extends JPanel {

    public Suggested_Products(int productID, int userID, JPanel Back) {
        setLayout(null);

        JLabel Also_Like_Heading = new JLabel("You may also like");
        Also_Like_Heading.setFont(Also_Like_Heading.getFont().deriveFont(16f));
        Also_Like_Heading.setBounds(0, 0, 225, 25);
        add(Also_Like_Heading);

        int amount_suggested = 10;
        int padding = 5;
        JPanel Also_Like_Content = new JPanel(null);

        ResultSet allorders = OrderingSystem.CL.Database.processRequest("SELECT * FROM `order`");
        ArrayList<product> suggested = getSuggestedProducts(allorders, productID, amount_suggested);
        amount_suggested = suggested.size();

        int pref_width = ((120 * amount_suggested) + (padding * (amount_suggested - 1)));
        Also_Like_Content.setPreferredSize(new Dimension(pref_width, 135));

        int i = 0;
        while (i < amount_suggested) {
            product p = suggested.get(i);
            JPanel suggested_product = new JPanel(null);

            JLabel suggested_product_Icon = new JLabel();
            suggested_product_Icon.setIcon(p.image);
            suggested_product_Icon.setBounds(0, 0, 120, 120);
            suggested_product.add(suggested_product_Icon);

            JLabel suggested_product_name = new JLabel(p.name + " (" + ProductDetail.getPrice(p.price) + ")");
            suggested_product_name.setFont(suggested_product_name.getFont().deriveFont(9f));
            suggested_product_name.setBounds(0, 120, 120, 15);
            suggested_product.add(suggested_product_name);

            suggested_product.addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    ProductDetail PD = new ProductDetail(p.id, userID, Back, 0);
                    OrderingSystem.CL.GUI.setBackground(PD);
                }
            });

            suggested_product.setBounds(((120 + padding) * i), 0, 120, 135);
            Also_Like_Content.add(suggested_product);
            i++;
        }

        JScrollPane also_like_scroller = new JScrollPane(Also_Like_Content);
        also_like_scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        also_like_scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        also_like_scroller.setBorder(null);
        also_like_scroller.setBounds(0, 25, 225, 160);
        add(also_like_scroller);
    }

    ArrayList<product> getSuggestedProducts(ResultSet allorders, int productID, int amount_suggested) {
        Map<Integer, Integer> allOtherProducts = new HashMap<>();
        try {
            while (allorders.next()) {
                String contentOfOrder = allorders.getString("content");

                boolean containsProduct = false;
                String[] splitContent = contentOfOrder.split("X");
                //length - 1 weil Gesamtpreis ignoriert wird
                for (int i = 0; i < splitContent.length - 1; i++) {

                    if (splitContent[i].split("x")[1].equals("" + productID)) {
                        containsProduct = true;
                        break;
                    }
                }

                //Bestellung enthält dieses Produkt - alle anderen Produkte der Map hinzufügen oder ihren Count erhöhen
                if (containsProduct) {
                    for (int i = 0; i < splitContent.length - 1; i++) {
                        if (!splitContent[i].split("x")[1].equals("" + productID)) {
                            int other_productID = Integer.parseInt(splitContent[i].split("x")[1]);
                            int count = allOtherProducts.getOrDefault(other_productID, 0);
                            allOtherProducts.put(other_productID, (count + 1));
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProductDetail.class.getName()).log(Level.SEVERE, null, ex);
        }

        List<Integer> topProductIDs = allOtherProducts.entrySet().stream()
                .sorted((e1, e2) -> Integer.compare(e2.getValue(), e1.getValue())) // absteigend sortieren
                .limit(amount_suggested)
                .map(Map.Entry::getKey)
                .toList(); // Java 16+, alternativ collect to new ArrayList

        ArrayList<product> recommendedProducts = new ArrayList<>();
        for (int id : topProductIDs) {
            ResultSet rs = OrderingSystem.CL.Database.processRequest("SELECT * FROM product WHERE productID = '" + id + "'");

            try {
                while (rs.next()) {
                    String name = rs.getString("name");
                    double price = rs.getDouble("price");
                    ImageIcon image = Homepage.getImageFromBlob(rs.getBlob("image"), 120); // oder gewünschte Größe

                    recommendedProducts.add(new product(id, name, price, image));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return recommendedProducts;
    }

}

class product {

    int id;
    String name;
    double price;
    ImageIcon image;

    public product(int id, String name, double price, ImageIcon image) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.image = image;
    }
}
