package Profil;

import OrderDetail.OrderDetail;
import Productdetail.ProductDetail;
import bestellsystem.ErrorMessage;
import bestellsystem.Homepage.Homepage;
import bestellsystem.OrderingSystem;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JScrollPane;
import javax.swing.border.LineBorder;

public class Main_Profile extends JPanel {

    public Main_Profile(int userID, int action, int w, int h) {
        setLayout(null);

        JPanel Content = userID == -1 ? new NotLoggedInPanel(action, w, userID) : new LoggedInPanel(userID, w, h);
        Content.setBounds(0, 0, w, h);
        add(Content);

        setBackground(OrderingSystem.Background);
        for (Component C : getComponents()) {
            background(C, OrderingSystem.Background);
        }
    }

    public static String getUserInformation(String information, int type, int userID, String error) {
        ResultSet rs = bestellsystem.OrderingSystem.CL.Database.processRequest("SELECT * FROM user WHERE userID='" + userID + "'");
        String info = "";
        try {
            while (rs.next()) {
                switch (type) {
                    case 0 ->
                        info += rs.getInt(information);
                    case 1 ->
                        info += rs.getString(information);
                }
            }
        } catch (SQLException ex) {
            ErrorMessage ER = new ErrorMessage("Main of Profile", error);
            OrderingSystem.CL.GUI.setBackground(ER);
            return null;
        }
        return info;
    }

    public static String getUserInformation(String information, int type, String Name, String error) {
        ResultSet rs = bestellsystem.OrderingSystem.CL.Database.processRequest("SELECT * FROM user WHERE Name='" + Name + "'");
        String info = "";
        try {
            while (rs.next()) {
                switch (type) {
                    case 0 ->
                        info += rs.getInt(information);
                    case 1 ->
                        info += rs.getString(information);
                }
            }
        } catch (SQLException ex) {
            ErrorMessage ER = new ErrorMessage("Main of Profile", error);
            OrderingSystem.CL.GUI.setBackground(ER);
            return null;
        }
        return info;
    }

    void background(Component C, Color B) {
        if (C instanceof JPanel) {
            if (((JPanel) C).getComponents().length != 0) {
                for (Component C2 : ((JPanel) C).getComponents()) {
                    background(C2, B);
                }
            }
            if (C.getBackground().equals(new Color(238, 238, 238))) {
                C.setBackground(B);
            }

        }
    }
}

class NotLoggedInPanel extends JPanel {

    public NotLoggedInPanel(int action, int width, int userID) {
        setLayout(null);
        JTextField Name_Input = new JTextField();
        JPanel Name_Panel = new InputPanel("Name", "profil", Name_Input, 0, width);
        add(Name_Panel);

        JPasswordField Password_Input = new JPasswordField();
        JPanel Password_Panel = new InputPanel("Password", "password", Password_Input, 125, width);
        add(Password_Panel);

        JPasswordField Password_Again_Input = new JPasswordField();
        if (action == 1) {
            JPanel Password_Again_Panel = new InputPanel("Repeat Password", "password", Password_Again_Input, 250, width);
            add(Password_Again_Panel);
        }

        JPanel ButtonPanel = new JPanel(new GridBagLayout());
        ButtonPanel.setBounds(200, (275 + (100 * action)), 350, 50);
        JButton Button = new JButton((action == 0 ? "Login" : "Register"));
        Button.setPreferredSize(new Dimension(350, 50));
        Button.setFont(Button.getFont().deriveFont(34f));
        Button.setRolloverEnabled(false);
        Button.setFocusable(false);
        Button.setBorder(new LineBorder(Color.GRAY, 1));
        Button.setBackground(Color.ORANGE);
        ButtonPanel.add(Button);
        add(ButtonPanel);

        Button.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                String Name = Name_Input.getText();
                String Pass1 = "";
                for (Character c : Password_Input.getPassword()) {
                    Pass1 += c;
                }
                String Pass2 = "";
                for (Character c : Password_Again_Input.getPassword()) {
                    Pass2 += c;
                }

                if (Name.equals("") || Pass1.equals("") || (action == 1 && Pass2.equals(""))) {
                    JOptionPane.showMessageDialog(null, "Fill out all inputs!", "Error", JOptionPane.OK_OPTION);
                    return;
                }

                String userID = Main_Profile.getUserInformation("userID", 0, Name, "Checking userID");
                if (action == 0) {
                    if (userID.equals("")) {
                        JOptionPane.showMessageDialog(null, "User does not exist!", "Error", JOptionPane.OK_OPTION);
                        return;
                    }
                    if (!Pass1.equals(Main_Profile.getUserInformation("Password", 1, Name, "Checking Password!"))) {
                        JOptionPane.showMessageDialog(null, "Wrong password!", "Error", JOptionPane.OK_OPTION);
                        return;
                    }

                    OrderingSystem.CL.ProfilePanel = new Profile(Integer.parseInt(userID), 0);
                    OrderingSystem.CL.GUI.setBackground(OrderingSystem.CL.ProfilePanel);
                } else {
                    if (!userID.equals("")) {
                        JOptionPane.showMessageDialog(null, "User already exists!", "Error", JOptionPane.OK_OPTION);
                        return;
                    }
                    if (!Pass1.equals(Pass2)) {
                        JOptionPane.showMessageDialog(null, "Passwords are not equal!", "Error", JOptionPane.OK_OPTION);
                        return;
                    }

                    OrderingSystem.CL.Database.executeStatement("INSERT INTO user (`userID`, `Name`, `Password`, `shippingAdress`, `billingAdress`) VALUES (NULL, '" + Name + "', '" + Pass1 + "', '', '')");
                    userID = Main_Profile.getUserInformation("userID", 0, Name, "Checking userID!");
                    OrderingSystem.CL.ProfilePanel = new Profile(Integer.parseInt(userID), 0);
                    OrderingSystem.CL.GUI.setBackground(OrderingSystem.CL.ProfilePanel);
                }
            }
        });
    }
}

class LoggedInPanel extends JPanel {

    public LoggedInPanel(int userID, int width, int height) {
        setLayout(null);

        double ratio = 0.4;
        int leftW = (int) (width * ratio);
        JPanel User_Information = UserInformationPanel(userID, leftW);
        User_Information.setBounds(0, 0, leftW, height);
        add(User_Information);

        int rightW = width - leftW;
        JPanel Other = new JPanel(null);

        JPanel OrderingPanel = OrderingPanel(userID, rightW);
        OrderingPanel.setBounds(0, 0, rightW, 325);
        Other.add(OrderingPanel);

        JPanel SavingPanel = SavingPanel(userID, rightW);
        SavingPanel.setBounds(0, 350, rightW, 300);
        Other.add(SavingPanel);

        Other.setBounds(leftW, 0, rightW, height);
        add(Other);
    }

    private JPanel UserInformationPanel(int userID, int w) {
        JPanel User_Information = new JPanel(null);

        String Name = Main_Profile.getUserInformation("Name", 1, userID, "Checking Name!");
        JTextField Name_Input = new JTextField(Name);
        JPanel Name_Panel = new InputPanel("Name", "profil", Name_Input, 0, w);
        User_Information.add(Name_Panel);

        String Password = Main_Profile.getUserInformation("Password", 1, userID, "Checking Password!");
        JTextField Password_Input = new JTextField(Password);
        JPanel Password_Panel = new InputPanel("Password", "password", Password_Input, 125, w);
        User_Information.add(Password_Panel);

        String Shipping_Adress = Main_Profile.getUserInformation("shippingAdress", 1, userID, "Checking Shipping Adress!");
        JTextField Shipping_Adress_Input = new JTextField(Shipping_Adress);
        JPanel Adress_Panel = new InputPanel("Shipping Adress", "adress", Shipping_Adress_Input, 250, w);
        User_Information.add(Adress_Panel);

        String Billing_Adress = Main_Profile.getUserInformation("billingAdress", 1, userID, "Checking Billing Adress!");
        JTextField Billing_Adress_Input = new JTextField(Billing_Adress);
        Adress_Panel = new InputPanel("Billing Adress", "adress", Billing_Adress_Input, 375, w);
        User_Information.add(Adress_Panel);

        JPanel ButtonPanel = new JPanel(new GridBagLayout());
        ButtonPanel.setBounds((int) (w * 0.2), (500), (int) (w * 0.6), 50);
        JButton Button = new JButton(" Save ");
        Button.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                String New_Name = Name_Input.getText();
                String New_Pass = Password_Input.getText();
                String New_Ship = Shipping_Adress_Input.getText();
                String New_Bill = Billing_Adress_Input.getText();

                if (Name.equals(New_Name) && Password.equals(New_Pass) && Shipping_Adress.equals(New_Ship) && Billing_Adress.equals(New_Bill)) {
                    return;
                }

                if (Name.equals("") && Password.equals("") && Shipping_Adress.equals("") && Billing_Adress.equals("")) {
                    JOptionPane.showMessageDialog(null, "Fill out all inputs!", "Error", JOptionPane.OK_OPTION);
                    return;
                }

                String userIDForNew_Name = Main_Profile.getUserInformation("userID", 0, New_Name, "Checking userID!");
                if (!userIDForNew_Name.equals("") && !userIDForNew_Name.equals("" + userID)) {
                    JOptionPane.showMessageDialog(null, "User already exists!", "Error", JOptionPane.OK_OPTION);
                    return;
                }

                OrderingSystem.CL.Database.executeStatement("UPDATE `user` SET `Name` = '" + New_Name + "', `Password` = '" + New_Pass + "', `shippingAdress` = '" + New_Ship + "', `billingAdress` = '" + New_Bill + "' WHERE `user`.`userID` = " + userID + ";");
                JOptionPane.showMessageDialog(null, "Information successfully updated!", "Success", JOptionPane.INFORMATION_MESSAGE);
                OrderingSystem.CL.ProfilePanel = new Profile(userID, 2);
                OrderingSystem.CL.GUI.setBackground(OrderingSystem.CL.ProfilePanel);
            }
        });
        Button.setPreferredSize(new Dimension(350, 50));
        Button.setFont(Button.getFont().deriveFont(34f));
        Button.setRolloverEnabled(false);
        Button.setFocusable(false);
        Button.setBorder(new LineBorder(Color.GRAY, 1));
        Button.setBackground(Color.ORANGE);
        ButtonPanel.add(Button);
        User_Information.add(ButtonPanel);
        return User_Information;
    }

    private JPanel OrderingPanel(int userID, int w) {
        JPanel OrderingPanel = new JPanel(null);

        JPanel Heading = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel Heading_Label = new JLabel("Your Orders");
        Heading_Label.setFont(Heading_Label.getFont().deriveFont(26f));
        Heading_Label.setIcon(new ImageIcon(new ImageIcon("src//bestellsystem//img//order.png").getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH)));
        Heading.add(Heading_Label);
        Heading.setBounds(0, 0, w, 35);
        OrderingPanel.add(Heading);

        JPanel Desc = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel Desc_Label = new JLabel("Date" + (" ").repeat(35) + "Items   content" + (" ").repeat(98) + "sum" + (" ").repeat(13) + "shipping adress" + (" ").repeat(65) + "orderID");
        Desc_Label.setFont(Desc_Label.getFont().deriveFont(9f));
        Desc.add(Desc_Label);
        Desc.setBounds(0, 35, w, 15);
        OrderingPanel.add(Desc);

        JPanel Content = new JPanel(null);

        ArrayList<JPanel> Orders = new ArrayList<>();
        ResultSet rs = bestellsystem.OrderingSystem.CL.Database.processRequest("SELECT * FROM `order` WHERE userID='" + userID + "' ORDER BY placed DESC");
        int i = 0;
        try {
            while (rs.next()) {
                Timestamp timestamp = rs.getTimestamp("placed");
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy (HH:mm)");
                LocalDateTime ldt = timestamp.toLocalDateTime();
                String placed = ldt.format(formatter);
                int oderID = rs.getInt("orderID");
                String content = rs.getString("content");
                String adress = rs.getString("shippingAdress");

                JPanel order = new JPanel(null);
                JLabel placed_Label = new JLabel(placed);
                placed_Label.setBounds(0, 0, 100, 25);
                order.add(placed_Label);

                int amountOfItems = content.split("X").length - 1;
                JLabel Items_Label = new JLabel(amountOfItems + "");
                Items_Label.setBounds(110, 0, 20, 25);
                order.add(Items_Label);

                String contentToDisplay = "";
                for (int j = 0; j < content.split("X").length - 1; j++) {
                    String part = content.split("X")[j];
                    contentToDisplay += part.split("x")[0] + "* ";
                    ResultSet rs2 = OrderingSystem.CL.Database.processRequest("SELECT name FROM product WHERE productID='" + part.split("x")[1] + "'");
                    while (rs2.next()) {
                        contentToDisplay += rs2.getString("name") + " (";
                    }
                    contentToDisplay += String.valueOf((double) (Double.parseDouble(part.split("x")[2]))) + ")" + (j == content.split("X").length - 2 ? "" : " | ");
                }

                JLabel content_Label = new JLabel(contentToDisplay);
                content_Label.setBounds(140, 0, 260, 25);
                order.add(content_Label);

                String sum = content.split("X")[content.split("X").length - 1];
                JLabel sum_Label = new JLabel(sum);
                sum_Label.setBounds(410, 0, 45, 25);
                order.add(sum_Label);

                JLabel adress_Label = new JLabel(adress);
                adress_Label.setBounds(465, 0, 215, 25);
                order.add(adress_Label);

                int dig = 8;
                JLabel oderID_Label = new JLabel("0".repeat(dig - (String.valueOf(oderID).length())) + oderID);
                oderID_Label.setBounds(690, 0, 75, 25);
                order.add(oderID_Label);

                order.addMouseListener(new MouseAdapter() {
                    public void mousePressed(MouseEvent e) {
                        OrderDetail OD = new OrderDetail(oderID, userID, OrderingSystem.CL.ProfilePanel);
                        OrderingSystem.CL.GUI.setBackground(OD);

                    }
                });
                Orders.add(order);
                order.setBounds(0, (25 * i), w, 25);
                Content.add(order);
                i++;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Main_Profile.class.getName()).log(Level.SEVERE, null, ex);
        }
        Content.setPreferredSize(new Dimension(w, (25 * Orders.size())));

        if (Orders.size() > 13) {
            JScrollPane scroll = new JScrollPane(Content);
            scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
            scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
            scroll.setBorder(null);
            scroll.setBounds(0, 50, w, 275);
            OrderingPanel.add(scroll);
        } else {
            Content.setBounds(0, 50, w, 275);
            OrderingPanel.add(Content);
        }

        return OrderingPanel;
    }

    private JPanel SavingPanel(int userID, int w) {
        JPanel SavingPanel = new JPanel(null);

        JPanel Heading = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel Heading_Label = new JLabel("Your Favorites");
        Heading_Label.setFont(Heading_Label.getFont().deriveFont(26f));
        Heading_Label.setIcon(new ImageIcon(new ImageIcon("src//bestellsystem//img//heart_red.png").getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH)));
        Heading.add(Heading_Label);
        Heading.setBounds(0, 0, w, 33);
        SavingPanel.add(Heading);

        JPanel Content = new JPanel(null);

        ArrayList<JPanel> Favorites = new ArrayList<>();

        ResultSet rs = OrderingSystem.CL.Database.processRequest("SELECT * FROM isfavorite WHERE userID='" + userID + "' ORDER BY since DESC");
        int i = 0;
        try {
            while (rs.next()) {
                int productID = rs.getInt("productID");
                Timestamp since = rs.getTimestamp("since");

                JPanel fav = new JPanel(null);
                JLabel Product_Icon = new JLabel();
                ImageIcon image = null;
                ResultSet rs2 = OrderingSystem.CL.Database.processRequest("SELECT image FROM product WHERE productID='" + productID + "'");
                if (rs2.next()) {
                    image = Homepage.getImageFromBlob(rs2.getBlob("image"), 250); // Bild als Blob aus DB
                }
                Product_Icon.setIcon(image);
                Product_Icon.setBounds(0, 0, 250, 250);
                fav.add(Product_Icon);

                int amount = 0;
                rs2 = OrderingSystem.CL.Database.processRequest("SELECT COUNT(DISTINCT userID) AS amount FROM isfavorite WHERE productID='" + productID + "';");
                if (rs2.next()) {
                    amount = rs2.getInt("amount");
                }

                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy (HH:mm)");
                LocalDateTime ldt = since.toLocalDateTime();
                JLabel Since_Label = new JLabel("Favorite since: " + ldt.format(formatter) + " | Liked by " + (amount - 1) + " others");
                Since_Label.setFont(Since_Label.getFont().deriveFont(9f));
                Since_Label.setBounds(0, 250, 250, 15);
                fav.add(Since_Label);
                fav.setBounds((255 * i), 0, 250, 275);
                fav.addMouseListener(new MouseAdapter() {
                    public void mousePressed(MouseEvent e) {

                        ProductDetail PD = new ProductDetail(productID, userID, OrderingSystem.CL.ProfilePanel, 0);
                        OrderingSystem.CL.GUI.setBackground(PD);

                    }
                });
                Content.add(fav);
                Favorites.add(fav);
                i++;
            }
        } catch (SQLException ex) {
            Logger.getLogger(LoggedInPanel.class.getName()).log(Level.SEVERE, null, ex);
        }

        Content.setPreferredSize(new Dimension((i * 250 + ((i - 1) * 5)), (275)));
        if (Favorites.size() > 2) {
            JScrollPane scroll = new JScrollPane(Content);
            scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
            scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            scroll.setBorder(null);
            scroll.setBounds(0, 35, w, 290);
            SavingPanel.add(scroll);
        } else {
            Content.setBounds(0, 35, w, 275);
            SavingPanel.add(Content);
        }
        return SavingPanel;
    }
}

class InputPanel extends JPanel {

    public InputPanel(String Text, String Icon, JComponent Input, int y, int w) {
        setLayout(new GridLayout(2, 1));
        JPanel Panel_Label_Panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel Panel_Label = new JLabel(" " + Text);
        Panel_Label.setFont(Panel_Label.getFont().deriveFont(28f));
        Panel_Label.setIcon(new ImageIcon(new ImageIcon("src//bestellsystem//img//" + Icon + ".png").getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH)));
        Panel_Label_Panel.add(Panel_Label);
        add(Panel_Label_Panel);
        JPanel Panel_Input_Panel = new JPanel(null);
        Input.setBounds(5, 5, (w - 10), 40);
        Input.setFont(Input.getFont().deriveFont(22f));
        Panel_Input_Panel.add(Input);
        add(Panel_Input_Panel);
        setBounds(0, y, w, 100);
    }
}
