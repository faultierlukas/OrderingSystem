package Profil;

import bestellsystem.ErrorMessage;
import bestellsystem.OrderingSystem;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Profile extends JPanel {

    public Profile(int userID, int action) {
        //0 - Login, 1 - Register
        setLayout(null);
        Head_Profile Head = null;
        if (userID == -1) {
            Head = new Head_Profile(400, 100, 10, userID, action == 0 ? "Login" : "Sign up", (action == 0 ? 1 : 0));
        } else {
            Head = new Head_Profile(400, 100, 10, userID, "Welcome, " + getName(userID), 2);
        }

        Head.setBounds(0, 0, bestellsystem.GUI.SCREENWIDTH, 100);
        add(Head);

        double width = 0.6;
        int w = (int) (bestellsystem.GUI.SCREENWIDTH * width);
        int x = (bestellsystem.GUI.SCREENWIDTH - w) / 2;
        Main_Profile Main = null;

        if (userID == -1) {
            Main = new Main_Profile(userID, action, w, (bestellsystem.GUI.SCREENHEIGHT - 100));
            Main.setBounds(x, 100, w, (bestellsystem.GUI.SCREENHEIGHT - 100));
        } else {
            Main = new Main_Profile(userID, 2, bestellsystem.GUI.SCREENWIDTH, (bestellsystem.GUI.SCREENHEIGHT - 100));
            Main.setBounds(0, 100, bestellsystem.GUI.SCREENWIDTH, (bestellsystem.GUI.SCREENHEIGHT - 100));
        }
        add(Main);
    }

    public static String getName(int userID) {
        ResultSet rs = bestellsystem.OrderingSystem.CL.Database.processRequest("SELECT * FROM user WHERE userID='" + userID + "'");
        String Name = "";
        try {
            while (rs.next()) {
                Name += rs.getString("Name");
            }
        } catch (SQLException ex) {
            ErrorMessage ER = new ErrorMessage("Profile", "Error while getting Name!");
            OrderingSystem.CL.GUI.setBackground(ER);
            return "";
        }

        return Name;
    }
}
