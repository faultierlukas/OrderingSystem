package Search;

import bestellsystem.Head;
import bestellsystem.GUI;
import bestellsystem.Homepage.Homepage;
import bestellsystem.Product_Preview;
import bestellsystem.OrderingSystem;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;

public class SearchResult extends JPanel {

    public SearchResult(String input, int userID, JPanel Back) {
        setLayout(null);
        removeAll();

        JPanel Head = new Head(400, 100, 5, "Search Results: " + input, input, this, userID, false, Back, false);
        Head.setBounds(0, 0, bestellsystem.GUI.SCREENWIDTH, 100);
        add(Head);

        JComponent Content = Content(input, userID, Back);
        Content.setBounds(0, 100, bestellsystem.GUI.SCREENWIDTH, 650);
        add(Content);
    }

    private JComponent Content(String input, int userID, JPanel Back) {
        JPanel Content = new JPanel(null);
        Content.setBackground(OrderingSystem.Background);
        int pref_Height = 0;

        ArrayList<Product_Preview> strongMatches = new ArrayList<>();
        ArrayList<Product_Preview> weakMatches = new ArrayList<>();

        int padding = 25;
        int amount = 4;
        int w = (GUI.SCREENWIDTH - ((amount + 1) * padding)) / amount;
        int h = w + 50;

        ResultSet rs = OrderingSystem.CL.Database.processRequest("SELECT * FROM product");
        try {
            while (rs.next()) {
                String name = rs.getString("name");
                String description = rs.getString("description");
                List<String> tags = extractTags(name, description);

                double nameScore = getScore(input, name, description);
                double descScore = getScore(input, name, description) * 0.5;
                boolean keywordMatch = tags.stream().anyMatch(tag -> tag.contains(input.toLowerCase()));

                double finalScore = nameScore + descScore;
                if (keywordMatch) {
                    finalScore += 0.4;
                }

                Product_Preview panel = new Product_Preview(w, (h - w), Homepage.getImageFromBlob(rs.getBlob("image"), w), name, rs.getInt("amount"), description, rs.getInt("productID"), userID, this);

                if (finalScore >= 0.7) {
                    strongMatches.add(panel);
                } else if (finalScore >= 0.3) {
                    weakMatches.add(panel);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(SearchResult.class.getName()).log(Level.SEVERE, null, ex);
        }

        int x = 0;
        int y = 0;
        if (!strongMatches.isEmpty()) {
            for (int i = 0; i < strongMatches.size(); i++) {

                x = (i % amount) * (w) + (((i % amount) + 1) * padding);
                y = (i / amount) * (h) + (((i / amount) + 1) * padding);
                strongMatches.get(i).setBounds(x, y, w, h);
                Content.add(strongMatches.get(i));
            }
            pref_Height = (y + h + padding);
        } else {
            JPanel Error = new JPanel(new GridBagLayout());
            JLabel Maybe_Label = new JLabel("Sorry, we could not find the product you are looking for.");
            Maybe_Label.setFont(Maybe_Label.getFont().deriveFont(36f));
            Error.add(Maybe_Label);
            Error.setBounds(0, pref_Height, GUI.SCREENWIDTH, 50);
            Content.add(Error);
            pref_Height += 50;
        }

        if (!weakMatches.isEmpty()) {
            JPanel Maybe = new JPanel(new GridBagLayout());
            JLabel Maybe_Label = new JLabel("Maybe you meant...");
            Maybe_Label.setFont(Maybe_Label.getFont().deriveFont(36f));
            Maybe.add(Maybe_Label);
            Maybe.setBounds(0, pref_Height, GUI.SCREENWIDTH, 50);
            Content.add(Maybe);
            pref_Height += 50;

            for (int i = 0; i < weakMatches.size(); i++) {
                x = (i % amount) * (w) + (((i % amount) + 1) * padding);
                y = pref_Height + (i / amount) * (h) + (((i / amount) + 1) * padding);
                weakMatches.get(i).setBounds(x, y, w, h);
                Content.add(weakMatches.get(i));
            }
            pref_Height = (y + h + padding);
        }

        Content.setPreferredSize(new Dimension(GUI.SCREENWIDTH, pref_Height));

        if (pref_Height > 650) {
            JScrollPane scroller = new JScrollPane(Content);
            scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
            scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
            scroller.setBorder(null);
            return scroller;
        }
        return Content;
    }

    private List<String> extractTags(String name, String description) {
        List<String> tags = new ArrayList<>();
        if (name != null) {
            tags.addAll(List.of(name.toLowerCase().split(" ")));
        }
        if (description != null) {
            tags.addAll(List.of(description.toLowerCase().split(" ")));
        }
        return tags;
    }

    private double getScore(String input, String productName, String productDescription) {
        input = input.toLowerCase();
        productName = productName.toLowerCase();
        productDescription = productDescription.toLowerCase();

        int nameDistance = levenshteinDistance(input, productName);
        int maxLength = Math.max(input.length(), productName.length());
        double nameScore = (maxLength == 0) ? 1.0 : 1.0 - ((double) nameDistance / maxLength);

        // Additional matching score for description
        double descriptionScore = productDescription.contains(input) ? 0.5 : 0.0;

        // Keyword boost
        double keywordBoost = 0.0;
        String[] keywords = input.split(" ");
        for (String keyword : keywords) {
            if (productName.contains(keyword) || productDescription.contains(keyword)) {
                keywordBoost += 0.2;
            }
        }

        // Final score: name match (60%) + description (20%) + keyword boost (up to 20%)
        return Math.min(1.0, nameScore * 0.6 + descriptionScore * 0.2 + keywordBoost);
    }

    private int levenshteinDistance(String a, String b) {
        int[][] dp = new int[a.length() + 1][b.length() + 1];

        for (int i = 0; i <= a.length(); i++) {
            dp[i][0] = i;
        }
        for (int j = 0; j <= b.length(); j++) {
            dp[0][j] = j;
        }

        for (int i = 1; i <= a.length(); i++) {
            for (int j = 1; j <= b.length(); j++) {
                int cost = (a.charAt(i - 1) == b.charAt(j - 1)) ? 0 : 1;

                dp[i][j] = Math.min(
                        Math.min(dp[i - 1][j] + 1,
                                dp[i][j - 1] + 1),
                        dp[i - 1][j - 1] + cost);
            }
        }
        return dp[a.length()][b.length()];
    }
}
