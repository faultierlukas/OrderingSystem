package bestellsystem;

import Cart.Cart;
import Profil.Profile;
import Search.SearchResult;
import bestellsystem.OrderingSystem;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Head extends JPanel {

    /*
    Logo
    Title
    SearchBar -> input, icon
    Exit
    Profile
    cart
    Back
     */
    Color Background = Color.WHITE;
    Color Border_Color = Color.BLACK;
    Color Input_Foreground = new Color(124, 181, 24);

    public Head(int logoWidth, int logoHeight, int padding, String Title, String SearchBarInput, JPanel BackAfterNewSearch, int userID, boolean showProfile, JPanel Back, boolean cart) {
        setLayout(null);
        setBackground(Background);

        JLabel IconLabel = new JLabel();
        IconLabel.setIcon(new ImageIcon("src//bestellsystem//img//logo_" + logoWidth + ".png"));
        IconLabel.setBounds(0, 0, logoWidth, logoHeight);
        add(IconLabel);

        int iconSize = (logoHeight - (4 * padding)) / 2;
        String font_size = (double) iconSize * 0.6 + "f";

        JLabel Heading = new JLabel(Title);
        Heading.setFont(Heading.getFont().deriveFont(Float.parseFloat(font_size)));
        Heading.setForeground(new Color(239, 68, 68));
        Heading.setBounds((logoWidth + padding), padding, (bestellsystem.GUI.SCREENWIDTH - logoWidth - (5 * padding) - (2 * iconSize)), iconSize);
        add(Heading);

        if (SearchBarInput != null) {
            JPanel Border = new JPanel();
            Border.setBackground(Border_Color);
            Border.setBounds((logoWidth + padding), (int) (logoHeight / 2), (bestellsystem.GUI.SCREENWIDTH - logoWidth - (2 * padding)), 1);
            add(Border);

            JTextField input = new JTextField(SearchBarInput);
            input.setForeground(Input_Foreground);
            input.setFont(input.getFont().deriveFont(Float.parseFloat(font_size)));
            input.setBounds((logoWidth + padding), ((logoHeight / 2) + padding), (bestellsystem.GUI.SCREENWIDTH - logoWidth - (3 * padding) - iconSize), iconSize);
            add(input);

            JLabel Search_Icon = new JLabel(new ImageIcon(new ImageIcon("src//bestellsystem//img//suche.png").getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH)));
            Search_Icon.setBounds((bestellsystem.GUI.SCREENWIDTH - padding - iconSize), (int) ((logoHeight / 2) + padding), iconSize, iconSize);
            Search_Icon.addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    if (input.getText().isEmpty()) {
                        return;
                    }

                    SearchResult RS = new SearchResult(input.getText(), userID, BackAfterNewSearch);
                    OrderingSystem.CL.GUI.setBackground(RS);
                }
            });
            add(Search_Icon);
        }

        if (Back != null) {
            JLabel Back_Icon = new JLabel(new ImageIcon(new ImageIcon("src//bestellsystem//img//back.png").getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH)));
            Back_Icon.setBounds((bestellsystem.GUI.SCREENWIDTH - iconSize - padding), padding, iconSize, iconSize);
            Back_Icon.addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    if(Back.equals(OrderingSystem.CL.Homepage)){
                        OrderingSystem.CL.Homepage.reloadCart(userID);
                    }
                    OrderingSystem.CL.GUI.setBackground(Back);
                }
            });
            add(Back_Icon);
        } else {
            JLabel Exit_Icon = new JLabel(new ImageIcon(new ImageIcon("src//bestellsystem//img//aus.png").getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH)));
            Exit_Icon.setBounds((bestellsystem.GUI.SCREENWIDTH - iconSize - padding), padding, iconSize, iconSize);
            Exit_Icon.addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    if (OrderingSystem.CL.Database.closeConnection()) {
                        System.exit(0);
                    }
                }
            });
            add(Exit_Icon);
        }

        if (showProfile) {
            JLabel Profile_Icon = new JLabel(new ImageIcon(new ImageIcon("src//bestellsystem//img//profil.png").getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH)));
            Profile_Icon.setBounds((bestellsystem.GUI.SCREENWIDTH - (2 * iconSize) - (3 * padding)), padding, iconSize, iconSize);
            Profile_Icon.addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    OrderingSystem.CL.ProfilePanel = new Profile(userID, 0);
                    OrderingSystem.CL.GUI.setBackground(OrderingSystem.CL.ProfilePanel);
                }
            });
            add(Profile_Icon);
        }

        if (cart) {
            JLabel Cart_Icon = new JLabel(new ImageIcon(new ImageIcon("src//bestellsystem//img//cart.png").getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH)));
            Cart_Icon.setBounds((bestellsystem.GUI.SCREENWIDTH - (3 * iconSize) - (4 * padding)), padding, iconSize, iconSize);
            Cart_Icon.addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    if (userID != -1) {
                        Cart Cart = new Cart(userID);
                        OrderingSystem.CL.GUI.setBackground(Cart);
                    }
                }
            });
            add(Cart_Icon);

            String cart_val = "X - Log in";
            if (userID != -1) {
                ResultSet rs = OrderingSystem.CL.Database.processRequest("SELECT COUNT(DISTINCT productID) AS count FROM cart WHERE userID='" + userID + "'");
                try {
                    if (rs.next()) {
                        cart_val = "" + rs.getInt("count");
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(Head.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            JLabel Cart_Value = new JLabel(cart_val);
            Cart_Value.setFont(Cart_Value.getFont().deriveFont(8f));
            Cart_Value.setBounds((int) (bestellsystem.GUI.SCREENWIDTH - (3 * iconSize) - ((userID == -1 ? 4.5 : 3) * padding)), (padding + 15), iconSize + 10, 18);
            add(Cart_Value);

        }
    }
}
