package bestellsystem.Homepage;

import bestellsystem.Product_Preview;
import static bestellsystem.Homepage.Homepage.getImageFromBlob;
import bestellsystem.OrderingSystem;
import java.awt.Color;
import java.awt.Dimension;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class Main_Homepage extends JPanel {

    JScrollPane scroll;

    public Main_Homepage(int ItemsPerColumn, int padding, int descHeight, int sumWidth, int sumHeight, ResultSet products, int userID) {
        setLayout(null);
        setBackground(OrderingSystem.Background);

        int width = ((-padding * ItemsPerColumn + (sumWidth - padding)) / ItemsPerColumn);

        ArrayList<JPanel> productPanels = new ArrayList<>();
        try {
            while (products.next()) {
                ImageIcon image = getImageFromBlob(products.getBlob("image"), width); // Bild als Blob aus DB
                String name = products.getString("name"); // Produktname
                int amount = products.getInt("amount"); // Anzahl
                int productID = products.getInt("productID");
                String description = products.getString("description"); // Beschreibung
                productPanels.add(new Product_Preview(width, descHeight, image, name, amount, description, productID, userID, OrderingSystem.CL.Homepage));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        int productCount = productPanels.size();

        for (int i = 0; i < productCount; i++) {
            int x = (i % ItemsPerColumn) * (width + padding) + padding;
            int y = (i / ItemsPerColumn) * (width + padding + descHeight) + padding;
            productPanels.get(i).setBounds(x, y, width, (width + descHeight));
            add(productPanels.get(i));
        }

        //Höhe der Panels (
        int rows = (int) Math.ceil(productCount / (ItemsPerColumn * 1.0));
        int height = rows * (width + descHeight) + (rows + 1) * padding;

        setPreferredSize(new Dimension(sumWidth, height));
        JPanel Border = new JPanel();
        Border.setBounds(0, 0, 1, height > sumHeight ? height : sumHeight);
        Border.setBackground(Color.BLACK);
        add(Border);

        //setBackground(new Color(222, 214, 213));
        if (height >= (sumHeight - 2 * padding)) {
            scroll = new JScrollPane(this);
            scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
            scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
            scroll.setBorder(null);
        }
    }
}