package bestellsystem;

import java.awt.Color;

public class OrderingSystem {

    public static ClassList CL;

    /*
    TO-DO:
    - clean the code (simplify, unify and create GUI-variables)
    - test
    - set up example-database
    - create Admin-Panel (idea: userID -> 0):
     - create, edit and delete products
     - edit the GUI (clean coded needed!)
     - change user information?
    - fix bugs:
     - Profile: Favorites are still shown in the list after removing them (removing works fine, reload needed)
     - Cart: Items are still shown after removing them (removing works, reload needed)
     */
    public static Color Background = new Color(245, 245, 245);

    public static void main(String[] args) {
        CL = new ClassList();
        if (CL.Database.createConnection()) {
            //CL.Database.createContent();
            CL.Homepage.loadComponents(0, -1);
            CL.GUI.setBackground(CL.Homepage);
        }
        CL.GUI.setVisible(true);
    }

}
