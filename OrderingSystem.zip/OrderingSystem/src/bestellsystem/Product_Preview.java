package bestellsystem;

import Productdetail.ProductDetail;
import bestellsystem.OrderingSystem;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Product_Preview extends JPanel {

    public int amount;
    public int productID;
    public double price;

    public Product_Preview(int width, int descHeight, ImageIcon image, String name, int amount, String description, int productID, int userID, JPanel Back) {
        setLayout(null);
        setPreferredSize(new Dimension(width, (width + descHeight)));

        this.productID = productID;
        this.amount = amount;

        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                ProductDetail PD = new ProductDetail(productID, userID, Back, 0);
                OrderingSystem.CL.GUI.setBackground(PD);
            }
        });

        // Produktbild
        JLabel imageLabel = new JLabel(image);
        imageLabel.setBounds(1, 1, width - 2, width);
        add(imageLabel);

        JPanel Info = new JPanel(null);

        JPanel Name = new JPanel(new GridBagLayout());
        JLabel NameLabel = new JLabel(name);
        NameLabel.setFont(NameLabel.getFont().deriveFont(Float.parseFloat((descHeight * 0.4) + "f")));
        Name.add(NameLabel);
        NameLabel.setForeground(new Color(51, 51, 51));
        Name.setBackground(Color.WHITE);
        Name.setBounds(0, 0, width - 2, (int) (descHeight * 0.6));
        Info.add(Name);

        JPanel Desc = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel DescLabel = new JLabel(description);
        DescLabel.setFont(DescLabel.getFont().deriveFont(Float.parseFloat((descHeight * 0.2) + "f")));
        Desc.add(DescLabel);
        DescLabel.setForeground(new Color(107, 114, 128));
        Desc.setBounds(0, (int) (descHeight * 0.6), width, (int) (descHeight * 0.4));
        Desc.setBackground(Color.WHITE);
        Info.add(Desc);

        Info.setBounds(1, width + 1, width - 2, descHeight - 2);
        add(Info);

        JPanel Border = new JPanel();
        Border.setBackground(new Color(211, 211, 211));
        Border.setBounds(0, 0, width, (width + descHeight));
        add(Border);

        Color defaultTitleColor = NameLabel.getForeground();
        Color defaultDescColor = DescLabel.getForeground();

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                NameLabel.setForeground(new Color(59, 130, 246)); // Soft blue
                DescLabel.setForeground(new Color(250, 204, 21));

            }

            @Override
            public void mouseExited(MouseEvent e) {
                NameLabel.setForeground(defaultTitleColor);
                DescLabel.setForeground(defaultDescColor);
            }
        });
    }
}
